import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Mic2, Library, BarChart3, Settings, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import logoUrl from "@/assets/petty-richard-logo.png";

const items = [
  { to: "/dashboard", label: "Forge", icon: LayoutDashboard },
  { to: "/brand-voice", label: "Brand Voice", icon: Mic2 },
  { to: "/assets", label: "Asset Library", icon: Library },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/account", label: "Account", icon: Settings },
] as const;

export function AppSidebar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { user } = useAuth();

  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-border/60 bg-sidebar p-4 md:flex">
      <Link to="/" className="mb-8 flex items-center gap-2.5 px-2 py-1 group">
        <img
          src={logoUrl}
          alt="Petty Richard"
          width={120}
          height={60}
          className="h-7 w-auto transition-transform duration-300 group-hover:scale-105"
        />
        <span className="text-base font-bold uppercase italic tracking-tight">Forge</span>
      </Link>

      <div className="mono mb-2 px-2 text-[10px] uppercase tracking-widest text-muted-foreground">Engine</div>
      <nav className="flex flex-col gap-1">
        {items.map((it) => {
          const active = path === it.to;
          const Icon = it.icon;
          return (
            <Link
              key={it.to}
              to={it.to}
              className={`group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all ${
                active
                  ? "bg-foreground/[0.06] text-foreground"
                  : "text-muted-foreground hover:bg-foreground/[0.03] hover:text-foreground"
              }`}
            >
              <Icon className={`size-4 ${active ? "text-teal" : ""}`} />
              {it.label}
              {active && <span className="ml-auto inline-block size-1.5 rounded-full bg-teal" />}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto space-y-3">
        <div className="rounded-xl glass p-3">
          <div className="mono mb-1 text-[10px] uppercase tracking-widest text-muted-foreground">Plan</div>
          <div className="text-sm font-semibold">Starter</div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-foreground/5">
            <div className="h-full w-1/4 bg-gradient-to-r from-teal to-purple" />
          </div>
          <div className="mono mt-2 text-[10px] text-muted-foreground">2 / 10 forges</div>
        </div>
        <button
          onClick={() => supabase.auth.signOut()}
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-muted-foreground transition-colors hover:bg-foreground/[0.03] hover:text-foreground"
        >
          <LogOut className="size-3.5" />
          <span className="truncate">{user?.email}</span>
        </button>
      </div>
    </aside>
  );
}
