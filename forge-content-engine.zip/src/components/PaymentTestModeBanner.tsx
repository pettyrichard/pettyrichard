const clientToken = import.meta.env.VITE_PAYMENTS_CLIENT_TOKEN as string | undefined;

export function PaymentTestModeBanner() {
  if (!clientToken?.startsWith("pk_test_")) return null;
  return (
    <div className="w-full border-b border-teal/20 bg-gradient-to-r from-teal/[0.06] via-purple/[0.06] to-teal/[0.06] px-4 py-2 text-center">
      <p className="mono text-[10px] uppercase tracking-[0.22em] text-teal">
        <span className="mr-2 inline-block size-1.5 rounded-full bg-teal align-middle shadow-[0_0_8px_var(--teal)]" />
        Test mode · Use card 4242 4242 4242 4242 · No real charges{" "}
        <a
          href="https://docs.lovable.dev/features/payments#test-and-live-environments"
          target="_blank"
          rel="noopener noreferrer"
          className="ml-2 underline decoration-teal/40 underline-offset-4 hover:decoration-teal"
        >
          Learn more
        </a>
      </p>
    </div>
  );
}
