import { Link } from "@tanstack/react-router";
import logoUrl from "@/assets/petty-richard-logo.png";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-8 px-6 md:flex-row">
        <div className="flex items-center gap-4 text-center md:text-left">
          <img
            src={logoUrl}
            alt="Petty Richard"
            width={120}
            height={60}
            loading="lazy"
            className="h-9 w-auto"
          />
          <div>
            <p className="text-lg font-bold uppercase italic tracking-tight">Forge</p>
            <p className="mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Designed for relevance. Built for scale.
            </p>
          </div>
        </div>
        <p className="text-sm font-medium text-foreground/90">
          Forge Content Engine <span className="text-muted-foreground">by</span>{" "}
          <span className="font-semibold">Petty Richard</span>
        </p>
        <div className="mono flex gap-6 text-[10px] uppercase text-muted-foreground">
          <Link to="/pricing" className="hover:text-foreground transition-colors">Pricing</Link>
          <a href="#" className="hover:text-foreground transition-colors">Security</a>
          <a href="#" className="hover:text-foreground transition-colors">Terms</a>
        </div>
      </div>
    </footer>
  );
}
