import { Copy, Calendar, Share2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { ViralityScore } from "./ViralityScore";
import { PLATFORM_LABELS, type MockAsset } from "@/lib/forge-mock";

export function AssetCard({
  asset,
  index = 0,
  onPublish,
  published,
}: {
  asset: MockAsset;
  index?: number;
  onPublish?: (id: string) => void | Promise<void>;
  published?: boolean;
}) {
  return (
    <div
      className="group relative flex flex-col gap-4 rounded-xl glass p-5 transition-all duration-300 hover:-translate-y-1 hover:ring-glow-teal"
      style={{ animation: `var(--animate-reveal)`, animationDelay: `${index * 40}ms` }}
    >
      <div className="flex items-start justify-between">
        <span className="mono rounded bg-foreground/5 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-foreground/80">
          {PLATFORM_LABELS[asset.platform]}
        </span>
        <ViralityScore score={asset.virality} />
      </div>
      <p className="line-clamp-5 text-sm leading-relaxed text-foreground/85 whitespace-pre-line">{asset.content}</p>
      <div className="mt-auto flex items-center justify-between border-t border-border/60 pt-3">
        <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
          <ShieldCheck className="size-3 text-success" />
          <span className="mono uppercase tracking-wider">Fact-checked</span>
        </div>
        <div className="flex items-center gap-1">
          <IconBtn onClick={() => { navigator.clipboard.writeText(asset.content); toast.success("Copied to clipboard"); }}>
            <Copy className="size-3.5" />
          </IconBtn>
          <IconBtn onClick={() => toast.info("Scheduler opens in v1.1")}>
            <Calendar className="size-3.5" />
          </IconBtn>
          <IconBtn
            onClick={() => (onPublish ? onPublish(asset.id) : toast.info("Publish flow opens in v1.1"))}
            primary
            disabled={published}
          >
            <Share2 className="size-3.5" />
          </IconBtn>
        </div>
      </div>
    </div>
  );
}

function IconBtn({ children, onClick, primary, disabled }: { children: React.ReactNode; onClick: () => void; primary?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`grid size-7 place-items-center rounded-md transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
        primary
          ? "bg-teal text-background hover:brightness-110"
          : "border border-border text-muted-foreground hover:text-foreground hover:border-foreground/30"
      }`}
    >
      {children}
    </button>
  );
}
