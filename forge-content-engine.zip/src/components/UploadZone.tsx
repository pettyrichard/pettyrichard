import { useState } from "react";
import { Upload, Link as LinkIcon, FileText, Mic, Youtube, Sparkles } from "lucide-react";
import { toast } from "sonner";

export function UploadZone({ onGenerate }: { onGenerate: () => void }) {
  const [drag, setDrag] = useState(false);
  const [url, setUrl] = useState("");

  return (
    <div className="space-y-4">
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (e.dataTransfer.files.length) {
            toast.success(`${e.dataTransfer.files[0].name} queued`);
          }
        }}
        className={`relative grid place-items-center rounded-2xl border border-dashed transition-all duration-300 px-8 py-20 text-center ${
          drag
            ? "border-teal bg-teal/5 ring-glow-teal"
            : "border-border bg-surface/40 hover:border-foreground/30"
        }`}
      >
        <div className="pointer-events-none absolute inset-0 -z-10 rounded-2xl bg-[radial-gradient(circle_at_50%_0%,color-mix(in_oklab,var(--teal)_20%,transparent),transparent_60%)] opacity-60" />

        <div className="flex flex-col items-center gap-5">
          <div className="grid size-16 place-items-center rounded-2xl bg-foreground/5 ring-1 ring-border">
            <Upload className="size-6 text-teal" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-2xl font-semibold tracking-tight">Drop your source asset</h3>
            <p className="text-sm text-muted-foreground">
              Video, audio, PDF, image, or article. We'll handle the rest.
            </p>
          </div>
          <div className="mono flex flex-wrap items-center justify-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
            <Chip icon={<Youtube className="size-3" />}>video</Chip>
            <Chip icon={<Mic className="size-3" />}>audio</Chip>
            <Chip icon={<FileText className="size-3" />}>pdf · blog</Chip>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 rounded-xl border border-border bg-surface/40 p-2 focus-within:ring-glow-teal focus-within:border-teal/50 transition-all">
        <LinkIcon className="ml-2 size-4 text-muted-foreground" />
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="…or paste a YouTube, blog, podcast, or article URL"
          className="flex-1 bg-transparent px-1 py-2 text-sm outline-none placeholder:text-muted-foreground"
        />
        <button
          onClick={() => { if (!url) { toast.error("Add a URL or drop a file"); return; } onGenerate(); }}
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-semibold text-background transition-all hover:opacity-90 active:scale-[0.98]"
        >
          <Sparkles className="size-3.5" />
          Generate assets
        </button>
      </div>
    </div>
  );
}

function Chip({ children, icon }: { children: React.ReactNode; icon: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-foreground/[0.03] px-2.5 py-1">
      {icon}
      {children}
    </span>
  );
}
