import { Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import logoUrl from "@/assets/petty-richard-logo.png";

export function SiteNav() {
  const { user } = useAuth();
  return (
    <nav className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <div className="flex items-center gap-10">
          <Link to="/" className="flex items-center gap-3 group">
            <img
              src={logoUrl}
              alt="Petty Richard"
              width={120}
              height={60}
              className="h-7 w-auto transition-transform duration-300 group-hover:scale-105"
            />
            <span className="hidden text-base font-bold uppercase italic tracking-tight sm:inline">Forge</span>
          </Link>
          <div className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <Link to="/" className="hover:text-foreground transition-colors">Platform</Link>
            <Link to="/pricing" className="hover:text-foreground transition-colors">Pricing</Link>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {user ? (
            <Link
              to="/dashboard"
              className="rounded-md bg-foreground px-4 py-2 text-sm font-semibold text-background transition-opacity hover:opacity-90"
            >
              Open dashboard
            </Link>
          ) : (
            <>
              <Link to="/login" className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Log in</Link>
              <Link
                to="/signup"
                className="rounded-md bg-foreground px-4 py-2 text-sm font-semibold text-background transition-opacity hover:opacity-90"
              >
                Start free
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
