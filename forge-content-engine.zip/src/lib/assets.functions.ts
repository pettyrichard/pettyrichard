import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const AssetInput = z.object({
  platform: z.string().min(1).max(64),
  asset_type: z.string().min(1).max(64),
  title: z.string().min(1).max(255),
  content: z.string().min(1).max(20000),
  virality_score: z.number().int().min(0).max(100),
});

export const saveGeneratedAssets = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ assets: z.array(AssetInput).min(1).max(50) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const rows = data.assets.map((a) => ({
      ...a,
      user_id: userId,
      status: "draft",
      fact_check_status: "passed",
    }));
    const { data: inserted, error } = await supabase
      .from("generated_assets")
      .insert(rows)
      .select("id, platform, title");
    if (error) throw new Error(error.message);
    return { assets: inserted ?? [] };
  });

export const publishAsset = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("generated_assets")
      .update({ status: "published", published_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
