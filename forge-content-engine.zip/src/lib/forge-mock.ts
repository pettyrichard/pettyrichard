// Mock data used to demo the dashboard before live generation is wired up.
export type Platform =
  | "linkedin_post"
  | "linkedin_carousel"
  | "x_thread"
  | "tiktok_script"
  | "reels_script"
  | "youtube_chapters"
  | "youtube_description"
  | "newsletter"
  | "email_sequence"
  | "reddit_post"
  | "pinterest_pin"
  | "blog_summary";

export const PLATFORM_LABELS: Record<Platform, string> = {
  linkedin_post: "LinkedIn Post",
  linkedin_carousel: "LinkedIn Carousel",
  x_thread: "X Thread",
  tiktok_script: "TikTok Script",
  reels_script: "Reels Script",
  youtube_chapters: "YouTube Chapters",
  youtube_description: "YouTube Description",
  newsletter: "Newsletter",
  email_sequence: "Email Sequence",
  reddit_post: "Reddit Post",
  pinterest_pin: "Pinterest Pin",
  blog_summary: "Blog Summary",
};

export interface MockAsset {
  id: string;
  platform: Platform;
  title: string;
  content: string;
  virality: number;
  factChecked: boolean;
}

export const MOCK_ASSETS: MockAsset[] = [
  {
    id: "1",
    platform: "linkedin_post",
    title: "The leverage post",
    content:
      "Stop treating content like a lottery. The algorithm doesn't reward effort — it rewards hooks. Here's the 3-line framework I used to grow from 800 to 84k followers in 11 months.",
    virality: 94,
    factChecked: true,
  },
  {
    id: "2",
    platform: "x_thread",
    title: "Content engine thread",
    content:
      "1/ Most creators are stuck doing manual labor. The smart ones built engines. Here's how to turn one podcast into 30 days of platform-native content (1/9)",
    virality: 91,
    factChecked: true,
  },
  {
    id: "3",
    platform: "tiktok_script",
    title: "Hook + payoff",
    content:
      "HOOK (0-2s): \"You're posting 5x a week and getting 200 views. Here's why.\"\nBEAT (2-8s): Show analytics screen.\nPAYOFF (8-30s): Three-step fix walkthrough.",
    virality: 88,
    factChecked: true,
  },
  {
    id: "4",
    platform: "newsletter",
    title: "Subject + lead",
    content:
      "Subject: The leverage model I wish I'd learned in year one\n\nHey — last week I wrote about content engines. A few of you asked for the underlying spreadsheet. Here it is, plus the 4 metrics I track weekly.",
    virality: 82,
    factChecked: true,
  },
  {
    id: "5",
    platform: "youtube_chapters",
    title: "Chapter markers",
    content:
      "0:00 The lie about consistency\n2:14 Why hooks beat hashtags\n6:40 The 3-line framework\n11:02 Real teardown: 84k follower thread\n18:30 Your homework",
    virality: 79,
    factChecked: true,
  },
  {
    id: "6",
    platform: "linkedin_carousel",
    title: "10-slide carousel",
    content:
      "Slide 1: Cover — \"The Content Engine\"\nSlide 2: The 99% problem\nSlide 3: What changed for me\n...\nSlide 10: Save this for later.",
    virality: 90,
    factChecked: true,
  },
  {
    id: "7",
    platform: "reels_script",
    title: "30s reel",
    content:
      "Frame 1: B-roll, big text \"I posted 1,200 times.\"\nFrame 2: Cut to face, \"Then I learned this.\"\nFrame 3: Whiteboard animation of the 3-line framework.",
    virality: 86,
    factChecked: true,
  },
  {
    id: "8",
    platform: "reddit_post",
    title: "r/Entrepreneur post",
    content:
      "[Long] After 4 years grinding, here's the one shift that finally moved the needle on inbound. No links, no upsell — just the playbook.",
    virality: 72,
    factChecked: true,
  },
  {
    id: "9",
    platform: "pinterest_pin",
    title: "Pin copy",
    content:
      "Pin title: \"The 3-line hook framework\"\nDescription: A free template for creators tired of guessing what will land.",
    virality: 64,
    factChecked: true,
  },
  {
    id: "10",
    platform: "youtube_description",
    title: "Full description",
    content:
      "In this episode I break down the exact content engine I use to turn a single podcast into 30 days of platform-native posts. Links, timestamps, and the spreadsheet below.",
    virality: 77,
    factChecked: true,
  },
  {
    id: "11",
    platform: "email_sequence",
    title: "5-email sequence",
    content:
      "Email 1: The problem (curiosity hook)\nEmail 2: The shift\nEmail 3: The framework\nEmail 4: Case study\nEmail 5: Offer.",
    virality: 81,
    factChecked: true,
  },
  {
    id: "12",
    platform: "blog_summary",
    title: "TL;DR + outline",
    content:
      "TL;DR: Stop creating, start engineering. One source asset → 12 distributions. Below: the framework, the tools, the metrics that matter.",
    virality: 75,
    factChecked: true,
  },
];

export function viralityColor(score: number) {
  if (score >= 85) return "text-success";
  if (score >= 70) return "text-teal";
  if (score >= 55) return "text-warning";
  return "text-muted-foreground";
}
