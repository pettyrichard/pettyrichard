import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { AuthShell, Input, Divider } from "./login";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Create your Forge account" }] }),
  component: Signup,
});

function Signup() {
  const nav = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: { full_name: fullName },
      },
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Check your email to verify your account");
    nav({ to: "/login" });
  };

  const onGoogle = async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/dashboard" });
    if (r.error) { toast.error("Google sign-in failed"); return; }
    if (!r.redirected) nav({ to: "/dashboard" });
  };

  return (
    <AuthShell title="Start forging" subtitle="Free to try. No credit card.">
      <button onClick={onGoogle} className="mb-4 w-full rounded-lg border border-border bg-foreground/[0.03] py-2.5 text-sm font-semibold transition-all hover:bg-foreground/[0.06]">
        Continue with Google
      </button>
      <Divider />
      <form onSubmit={onSubmit} className="space-y-3">
        <Input label="Full name" value={fullName} onChange={setFullName} />
        <Input label="Email" type="email" value={email} onChange={setEmail} />
        <Input label="Password" type="password" value={password} onChange={setPassword} />
        <button disabled={busy} className="mt-2 w-full rounded-lg bg-foreground py-2.5 text-sm font-semibold text-background transition-opacity hover:opacity-90 disabled:opacity-50">
          {busy ? "Creating…" : "Create account"}
        </button>
      </form>
      <p className="mt-5 text-center text-xs text-muted-foreground">
        Have an account? <Link to="/login" className="text-foreground underline-offset-2 hover:underline">Log in</Link>
      </p>
    </AuthShell>
  );
}
