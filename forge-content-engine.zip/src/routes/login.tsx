import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Log in — Forge" }] }),
  component: Login,
});

function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Welcome back");
    nav({ to: "/dashboard" });
  };

  const onGoogle = async () => {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/dashboard" });
    if (result.error) { toast.error("Google sign-in failed"); return; }
    if (!result.redirected) nav({ to: "/dashboard" });
  };

  return <AuthShell title="Welcome back" subtitle="Log in to your Forge engine.">
    <button onClick={onGoogle} className="mb-4 w-full rounded-lg border border-border bg-foreground/[0.03] py-2.5 text-sm font-semibold transition-all hover:bg-foreground/[0.06]">
      Continue with Google
    </button>
    <Divider />
    <form onSubmit={onSubmit} className="space-y-3">
      <Input label="Email" type="email" value={email} onChange={setEmail} />
      <Input label="Password" type="password" value={password} onChange={setPassword} />
      <button disabled={busy} className="mt-2 w-full rounded-lg bg-foreground py-2.5 text-sm font-semibold text-background transition-opacity hover:opacity-90 disabled:opacity-50">
        {busy ? "Signing in…" : "Log in"}
      </button>
    </form>
    <p className="mt-5 text-center text-xs text-muted-foreground">
      New here? <Link to="/signup" className="text-foreground underline-offset-2 hover:underline">Create an account</Link>
    </p>
  </AuthShell>;
}

export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen place-items-center px-6 py-16">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--teal)_15%,transparent),transparent_55%)]" />
      <div className="w-full max-w-md" style={{ animation: "var(--animate-reveal)" }}>
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <span className="inline-block size-2 rounded-full bg-teal shadow-[0_0_12px_color-mix(in_oklab,var(--teal)_80%,transparent)]" />
          <span className="text-base font-bold uppercase italic tracking-tight">Forge</span>
        </Link>
        <div className="rounded-2xl glass-strong p-7">
          <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
          <div className="mt-6">{children}</div>
        </div>
        <p className="mono mt-6 text-center text-[10px] uppercase tracking-widest text-muted-foreground">
          Forge Content Engine by Petty Richard
        </p>
      </div>
    </div>
  );
}

export function Input({ label, type = "text", value, onChange }: { label: string; type?: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <div className="mono mb-1.5 text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
        className="w-full rounded-lg border border-border bg-foreground/[0.02] px-3 py-2.5 text-sm outline-none transition-all placeholder:text-muted-foreground focus:border-teal/50 focus:ring-glow-teal"
      />
    </label>
  );
}

export function Divider() {
  return (
    <div className="my-5 flex items-center gap-3">
      <div className="h-px flex-1 bg-border" />
      <span className="mono text-[9px] uppercase tracking-widest text-muted-foreground">or</span>
      <div className="h-px flex-1 bg-border" />
    </div>
  );
}
