import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Plus, Mic2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/brand-voice")({
  head: () => ({ meta: [{ title: "Brand Voice — Forge" }] }),
  component: BrandVoice,
});

const STEPS = ["Name your voice", "Paste 5 samples", "Calibrate tone", "Lock & save"] as const;

function BrandVoice() {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [samples, setSamples] = useState<string[]>(["", "", "", "", ""]);

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <header className="mb-10">
        <p className="mono mb-2 text-[10px] uppercase tracking-widest text-teal">Brand Voice Trainer</p>
        <h1 className="text-4xl font-bold tracking-tighter">Teach Forge how you sound.</h1>
        <p className="mt-2 text-sm text-muted-foreground">Train once. Every future asset matches your voice — automatically.</p>
      </header>

      {/* Stepper */}
      <div className="mb-8 flex items-center gap-2">
        {STEPS.map((label, i) => (
          <div key={label} className="flex flex-1 items-center gap-2">
            <div className={`grid size-7 place-items-center rounded-full mono text-[10px] font-bold transition-all ${
              i < step ? "bg-teal text-background" : i === step ? "ring-glow-teal bg-foreground text-background" : "bg-foreground/5 text-muted-foreground"
            }`}>
              {i < step ? <Check className="size-3.5" /> : i + 1}
            </div>
            {i < STEPS.length - 1 && <div className={`h-px flex-1 ${i < step ? "bg-teal" : "bg-border"}`} />}
          </div>
        ))}
      </div>

      <div className="rounded-2xl glass-strong p-7">
        <h2 className="text-xl font-semibold tracking-tight">{STEPS[step]}</h2>

        {step === 0 && (
          <div className="mt-5 space-y-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Petty's Executive Tone"
              className="w-full rounded-lg border border-border bg-foreground/[0.02] px-3 py-2.5 text-sm outline-none focus:border-teal/50 focus:ring-glow-teal"
            />
          </div>
        )}

        {step === 1 && (
          <div className="mt-5 space-y-3">
            {samples.map((s, i) => (
              <textarea
                key={i}
                value={s}
                onChange={(e) => setSamples((prev) => prev.map((x, j) => (j === i ? e.target.value : x)))}
                rows={3}
                placeholder={`Sample ${i + 1} — paste a piece of writing that sounds like you`}
                className="w-full resize-none rounded-lg border border-border bg-foreground/[0.02] px-3 py-2.5 text-sm outline-none focus:border-teal/50"
              />
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {[
              { k: "Energy", v: "Confident · Direct" },
              { k: "Rhythm", v: "Punchy · Short sentences" },
              { k: "Lexicon", v: "Editorial · Contrarian" },
              { k: "POV", v: "First-person operator" },
            ].map((t) => (
              <div key={t.k} className="rounded-xl border border-border bg-foreground/[0.02] p-4">
                <div className="mono mb-1 text-[10px] uppercase tracking-widest text-muted-foreground">{t.k}</div>
                <div className="text-sm font-semibold">{t.v}</div>
              </div>
            ))}
          </div>
        )}

        {step === 3 && (
          <div className="mt-6 flex flex-col items-center text-center">
            <Mic2 className="mb-3 size-8 text-teal" />
            <p className="text-sm text-muted-foreground">Your voice profile <b className="text-foreground">{name || "Untitled"}</b> is ready to lock in.</p>
          </div>
        )}

        <div className="mt-7 flex justify-between">
          <button
            disabled={step === 0}
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            className="rounded-lg px-4 py-2 text-sm text-muted-foreground hover:text-foreground disabled:opacity-30"
          >
            Back
          </button>
          {step < STEPS.length - 1 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              className="rounded-lg bg-foreground px-5 py-2 text-sm font-semibold text-background hover:opacity-90"
            >
              Continue
            </button>
          ) : (
            <button
              onClick={() => toast.success("Brand voice locked")}
              className="inline-flex items-center gap-2 rounded-lg bg-teal px-5 py-2 text-sm font-semibold text-background hover:brightness-110"
            >
              <Plus className="size-3.5" /> Save voice
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
