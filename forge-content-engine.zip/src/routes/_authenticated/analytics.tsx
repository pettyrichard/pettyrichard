import { createFileRoute } from "@tanstack/react-router";
import { TrendingUp, Eye, Heart, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({ meta: [{ title: "Analytics — Forge" }] }),
  component: Analytics,
});

const platforms = [
  { name: "LinkedIn", icon: "in", reach: "184.2k", engagement: "+38%", connected: true },
  { name: "X", icon: "𝕏", reach: "92.4k", engagement: "+12%", connected: true },
  { name: "TikTok", icon: "♪", reach: "—", engagement: "—", connected: false },
  { name: "YouTube", icon: "▶", reach: "—", engagement: "—", connected: false },
];

function Analytics() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <header className="mb-10">
        <p className="mono mb-2 text-[10px] uppercase tracking-widest text-teal">Performance loop</p>
        <h1 className="text-4xl font-bold tracking-tighter">Forge learns from your numbers.</h1>
      </header>

      <div className="mb-10 grid gap-4 md:grid-cols-4">
        {[
          { icon: Eye, label: "Total reach", value: "276.6k", trend: "+24%" },
          { icon: Heart, label: "Engagements", value: "18.9k", trend: "+41%" },
          { icon: MessageCircle, label: "Replies", value: "1,204", trend: "+18%" },
          { icon: TrendingUp, label: "Forge score", value: "87", trend: "+6 pts" },
        ].map((m) => (
          <div key={m.label} className="rounded-xl glass p-5">
            <m.icon className="mb-3 size-4 text-teal" />
            <div className="text-3xl font-bold tracking-tighter">{m.value}</div>
            <div className="mt-1 flex items-center justify-between">
              <span className="mono text-[10px] uppercase tracking-widest text-muted-foreground">{m.label}</span>
              <span className="mono text-[10px] font-bold text-success">{m.trend}</span>
            </div>
          </div>
        ))}
      </div>

      <h2 className="mb-4 text-lg font-semibold">Connected accounts</h2>
      <div className="grid gap-3 md:grid-cols-2">
        {platforms.map((p) => (
          <div key={p.name} className="flex items-center justify-between rounded-xl glass p-4">
            <div className="flex items-center gap-3">
              <span className="grid size-9 place-items-center rounded-lg bg-foreground/5 text-sm font-bold">{p.icon}</span>
              <div>
                <div className="text-sm font-semibold">{p.name}</div>
                <div className="mono text-[10px] uppercase text-muted-foreground">{p.connected ? `reach ${p.reach} · ${p.engagement}` : "Not connected"}</div>
              </div>
            </div>
            <button className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${p.connected ? "border border-border text-muted-foreground" : "bg-teal text-background hover:brightness-110"}`}>
              {p.connected ? "Connected" : "Connect"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
