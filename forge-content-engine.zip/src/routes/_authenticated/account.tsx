import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CreditCard, Sparkles, LogOut, Mail, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { createPortalSession } from "@/utils/payments.functions";
import { getStripeEnvironment } from "@/lib/stripe";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [{ title: "Account — Forge" }] }),
  component: Account,
});

type SubRow = {
  status: string;
  price_id: string | null;
  current_period_end: string | null;
  cancel_at_period_end: boolean | null;
};

const PLAN_LABELS: Record<string, { name: string; price: string; accent: "teal" | "purple" }> = {
  starter_monthly: { name: "Starter", price: "$29 / month", accent: "teal" },
  pro_monthly: { name: "Pro", price: "$79 / month", accent: "purple" },
  agency_monthly: { name: "Agency", price: "$199 / month", accent: "teal" },
};

function Account() {
  const { user } = useAuth();
  const [sub, setSub] = useState<SubRow | null>(null);
  const [loadingPortal, setLoadingPortal] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("subscriptions")
      .select("status, price_id, current_period_end, cancel_at_period_end")
      .eq("user_id", user.id)
      .eq("environment", getStripeEnvironment())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => setSub(data as SubRow | null));
  }, [user]);

  const planMeta = sub?.price_id ? PLAN_LABELS[sub.price_id] : null;
  const planName = planMeta?.name ?? "Free";
  const planPrice = planMeta?.price ?? "No active plan";
  const accent = planMeta?.accent ?? "teal";
  const isActive = sub && ["active", "trialing", "past_due"].includes(sub.status);
  const isCanceling = sub?.cancel_at_period_end;

  const handlePortal = async () => {
    setLoadingPortal(true);
    try {
      const url = await createPortalSession({
        data: {
          environment: getStripeEnvironment(),
          returnUrl: `${window.location.origin}/account`,
        },
      });
      if (url) window.open(url, "_blank");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not open billing portal");
    } finally {
      setLoadingPortal(false);
    }
  };

  return (
    <div className="relative min-h-screen">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[400px] bg-[radial-gradient(50%_50%_at_50%_0%,color-mix(in_oklab,var(--purple)_8%,transparent),transparent_70%)]" />
      <PaymentTestModeBanner />

      <div className="mx-auto max-w-3xl px-6 py-12">
        <header className="mb-10" style={{ animation: "var(--animate-reveal)" }}>
          <p className="mono mb-2 text-[10px] uppercase tracking-[0.22em] text-teal">Account</p>
          <h1 className="text-4xl font-bold tracking-tighter md:text-5xl">Manage your engine.</h1>
        </header>

        <div className="space-y-4">
          {/* Email card */}
          <div className="rounded-2xl glass p-6" style={{ animation: "var(--animate-reveal)" }}>
            <div className="mono mb-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              <Mail className="size-3" /> Signed in as
            </div>
            <div className="text-sm font-semibold">{user?.email}</div>
          </div>

          {/* Plan card */}
          <div
            className={`rounded-2xl p-6 md:p-7 ${
              isActive
                ? accent === "purple"
                  ? "glass-strong border border-purple/30 ring-glow-purple"
                  : "glass-strong border border-teal/30 ring-glow-teal"
                : "glass"
            }`}
            style={{ animation: "var(--animate-reveal)", animationDelay: "80ms" }}
          >
            <div className="mono mb-3 flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              <CreditCard className="size-3" /> Current plan
            </div>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold tracking-tighter">{planName}</span>
                  {isActive && (
                    <span className={`mono rounded-full px-2 py-0.5 text-[9px] uppercase tracking-[0.18em] ${
                      accent === "purple" ? "bg-purple/15 text-purple" : "bg-teal/15 text-teal"
                    }`}>
                      {sub?.status === "past_due" ? "Past due" : "Active"}
                    </span>
                  )}
                </div>
                <div className="mt-1 text-sm text-muted-foreground">{planPrice}</div>
                {isCanceling && sub?.current_period_end && (
                  <div className="mono mt-2 text-[10px] uppercase tracking-[0.18em] text-warning">
                    Cancels on {new Date(sub.current_period_end).toLocaleDateString()}
                  </div>
                )}
              </div>
              {isActive ? (
                <button
                  onClick={handlePortal}
                  disabled={loadingPortal}
                  className="group inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-background/40 px-5 py-3 text-sm font-semibold transition-all hover:border-teal/40 hover:text-teal disabled:opacity-50"
                >
                  {loadingPortal ? "Opening…" : "Manage billing"}
                  <ExternalLink className="size-3.5 opacity-60 transition-opacity group-hover:opacity-100" />
                </button>
              ) : (
                <Link
                  to="/pricing"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-foreground px-5 py-3 text-sm font-semibold text-background shadow-[0_8px_30px_-8px_var(--teal)] transition-opacity hover:opacity-90"
                >
                  <Sparkles className="size-3.5" /> Upgrade
                </Link>
              )}
            </div>
          </div>

          {/* Sign out */}
          <button
            onClick={async () => { await supabase.auth.signOut(); toast.success("Signed out"); }}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/30 bg-destructive/[0.03] py-3 text-sm font-semibold text-destructive transition-colors hover:bg-destructive/10"
          >
            <LogOut className="size-4" /> Sign out
          </button>
        </div>
      </div>
    </div>
  );
}
