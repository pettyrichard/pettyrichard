import { createFileRoute } from "@tanstack/react-router";
import { AssetCard } from "@/components/AssetCard";
import { MOCK_ASSETS } from "@/lib/forge-mock";

export const Route = createFileRoute("/_authenticated/assets")({
  head: () => ({ meta: [{ title: "Asset Library — Forge" }] }),
  component: Assets,
});

function Assets() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <header className="mb-10">
        <p className="mono mb-2 text-[10px] uppercase tracking-widest text-teal">Library</p>
        <h1 className="text-4xl font-bold tracking-tighter">Every asset you've ever forged.</h1>
      </header>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {MOCK_ASSETS.map((a, i) => <AssetCard key={a.id} asset={a} index={i} />)}
      </div>
    </div>
  );
}
