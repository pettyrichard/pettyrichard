import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import JSZip from "jszip";
import { useServerFn } from "@tanstack/react-start";
import { UploadZone } from "@/components/UploadZone";
import { AssetCard } from "@/components/AssetCard";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { MOCK_ASSETS, PLATFORM_LABELS } from "@/lib/forge-mock";
import { useAuth } from "@/hooks/use-auth";
import { saveGeneratedAssets, publishAsset } from "@/lib/assets.functions";
import { Download, FileJson, Share2, Loader2, Check } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Forge" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = useAuth();
  const [generated, setGenerated] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [exporting, setExporting] = useState<null | "json" | "zip">(null);
  const [publishing, setPublishing] = useState(false);
  const [publishProgress, setPublishProgress] = useState(0);
  const [publishedIds, setPublishedIds] = useState<Set<string>>(new Set());
  // Map mock id -> real DB uuid once persisted
  const [dbIdMap, setDbIdMap] = useState<Record<string, string>>({});

  const saveAssetsFn = useServerFn(saveGeneratedAssets);
  const publishAssetFn = useServerFn(publishAsset);

  const onGenerate = () => {
    setGenerating(true);
    setPublishedIds(new Set());
    setDbIdMap({});
    toast.success("Forging 12 assets…");
    setTimeout(() => { setGenerating(false); setGenerated(true); }, 1400);
  };

  const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  const triggerDownload = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  // Persist mock assets into Supabase once, return mock->db id map.
  const ensurePersisted = async (): Promise<Record<string, string>> => {
    if (Object.keys(dbIdMap).length === MOCK_ASSETS.length) return dbIdMap;
    const payload = MOCK_ASSETS.map((a) => ({
      platform: a.platform,
      asset_type: a.platform,
      title: a.title,
      content: a.content,
      virality_score: a.virality,
    }));
    const { assets } = await saveAssetsFn({ data: { assets: payload } });
    // Server returns in insert order, matching MOCK_ASSETS order
    const next: Record<string, string> = {};
    MOCK_ASSETS.forEach((a, i) => {
      const row = assets[i];
      if (row?.id) next[a.id] = row.id as string;
    });
    setDbIdMap(next);
    return next;
  };

  const exportJSON = async () => {
    setExporting("json");
    try {
      const idMap = await ensurePersisted();
      const payload = {
        exportedAt: new Date().toISOString(),
        userId: user?.id ?? null,
        count: MOCK_ASSETS.length,
        assets: MOCK_ASSETS.map((a) => ({
          id: idMap[a.id] ?? a.id,
          platform: a.platform,
          platformLabel: PLATFORM_LABELS[a.platform],
          title: a.title,
          content: a.content,
          viralityScore: a.virality,
          factChecked: a.factChecked,
        })),
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      triggerDownload(blob, `forge-assets-${Date.now()}.json`);
      toast.success("Exported & saved to your library", {
        description: `${MOCK_ASSETS.length} assets downloaded as JSON.`,
      });
    } catch (e) {
      toast.error("Export failed", { description: (e as Error).message });
    } finally {
      setExporting(null);
    }
  };

  const exportZIP = async () => {
    setExporting("zip");
    try {
      const idMap = await ensurePersisted();
      const zip = new JSZip();
      const folder = zip.folder("forge-assets")!;
      for (const a of MOCK_ASSETS) {
        const name = `${a.id.padStart(2, "0")}-${a.platform}-${slugify(a.title)}.md`;
        const md = `# ${a.title}\n\n**ID:** ${idMap[a.id] ?? a.id}  \n**Platform:** ${PLATFORM_LABELS[a.platform]}  \n**Virality:** ${a.virality}/100  \n**Fact-checked:** ${a.factChecked ? "yes" : "no"}\n\n---\n\n${a.content}\n`;
        folder.file(name, md);
      }
      folder.file("manifest.json", JSON.stringify(
        MOCK_ASSETS.map((a) => ({ ...a, dbId: idMap[a.id] ?? null })),
        null, 2,
      ));
      const blob = await zip.generateAsync({ type: "blob" });
      triggerDownload(blob, `forge-assets-${Date.now()}.zip`);
      toast.success("Exported & saved to your library", {
        description: `${MOCK_ASSETS.length} assets packaged as ZIP.`,
      });
    } catch (e) {
      toast.error("Export failed", { description: (e as Error).message });
    } finally {
      setExporting(null);
    }
  };

  const publishOne = async (mockId: string) => {
    try {
      const idMap = await ensurePersisted();
      const dbId = idMap[mockId];
      if (!dbId) throw new Error("Asset not persisted");
      await publishAssetFn({ data: { id: dbId } });
      setPublishedIds((prev) => new Set(prev).add(mockId));
      toast.success("Published to queue");
    } catch (e) {
      toast.error("Publish failed", { description: (e as Error).message });
    }
  };

  const publishAll = async () => {
    setPublishing(true);
    setPublishProgress(0);
    setPublishedIds(new Set());
    try {
      const idMap = await ensurePersisted();
      const total = MOCK_ASSETS.length;
      let failures = 0;
      for (let i = 0; i < total; i++) {
        const mock = MOCK_ASSETS[i];
        const dbId = idMap[mock.id];
        try {
          if (dbId) await publishAssetFn({ data: { id: dbId } });
          setPublishedIds((prev) => new Set(prev).add(mock.id));
        } catch {
          failures += 1;
        }
        setPublishProgress(Math.round(((i + 1) / total) * 100));
      }
      if (failures === 0) {
        toast.success(`Published ${total} assets`, { description: "All scheduled to your queue." });
      } else {
        toast.warning(`Published ${total - failures} of ${total}`, { description: `${failures} failed.` });
      }
    } catch (e) {
      toast.error("Publish failed", { description: (e as Error).message });
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="relative mx-auto max-w-7xl px-6 py-10">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[480px] bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--teal)_10%,transparent),transparent_65%),radial-gradient(ellipse_at_top_right,color-mix(in_oklab,var(--purple)_8%,transparent),transparent_55%)]" />
      <div className="mb-6">
        <PaymentTestModeBanner />
      </div>
      <header className="mb-10 flex items-end justify-between">
        <div>
          <p className="mono mb-2 text-[10px] uppercase tracking-widest text-teal">Active Forge</p>
          <h1 className="text-4xl font-bold tracking-tighter">
            Welcome back, {user?.user_metadata?.full_name?.split(" ")[0] || "creator"}.
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">Drop a source asset to generate 12+ platform-native pieces.</p>
        </div>
        <div className="mono hidden rounded-lg border border-border bg-surface px-3 py-1.5 text-[10px] uppercase tracking-widest text-muted-foreground md:block">
          Brand voice: <span className="text-teal">default</span>
        </div>
      </header>

      <UploadZone onGenerate={onGenerate} />

      {generating && (
        <div className="mt-10 grid place-items-center rounded-2xl glass py-16" style={{ animation: "var(--animate-fade-in)" }}>
          <div className="text-center">
            <div className="mx-auto mb-4 size-10 animate-pulse rounded-full bg-gradient-to-r from-teal to-purple" />
            <p className="mono text-[10px] uppercase tracking-widest text-muted-foreground">Forging assets across 12 platforms…</p>
          </div>
        </div>
      )}

      {generated && !generating && (
        <section className="mt-12">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold tracking-tight">Generated assets</h2>
              <span className="mono rounded bg-teal/10 px-2 py-1 text-[10px] font-bold text-teal ring-1 ring-teal/20">12 READY</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={exportJSON}
                disabled={exporting !== null || publishing}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-surface/40 px-3 py-1.5 text-xs font-medium text-muted-foreground transition-all hover:border-foreground/30 hover:text-foreground disabled:opacity-50"
              >
                {exporting === "json" ? <Loader2 className="size-3.5 animate-spin" /> : <FileJson className="size-3.5" />}
                JSON
              </button>
              <button
                onClick={exportZIP}
                disabled={exporting !== null || publishing}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-surface/40 px-3 py-1.5 text-xs font-medium text-muted-foreground transition-all hover:border-foreground/30 hover:text-foreground disabled:opacity-50"
              >
                {exporting === "zip" ? <Loader2 className="size-3.5 animate-spin" /> : <Download className="size-3.5" />}
                {exporting === "zip" ? "Packaging…" : "Export ZIP"}
              </button>
              <button
                onClick={publishAll}
                disabled={publishing || exporting !== null}
                className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-teal to-purple px-3 py-1.5 text-xs font-semibold text-background shadow-[0_4px_24px_-4px_color-mix(in_oklab,var(--teal)_50%,transparent)] transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-70"
              >
                {publishing ? <Loader2 className="size-3.5 animate-spin" /> : <Share2 className="size-3.5" />}
                {publishing ? `Publishing ${publishProgress}%` : "Publish all"}
              </button>
            </div>
          </div>

          {(publishing || publishedIds.size > 0) && (
            <div className="mb-6 rounded-xl glass p-4" style={{ animation: "var(--animate-fade-in)" }}>
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {publishing ? <Loader2 className="size-3.5 animate-spin text-teal" /> : <Check className="size-3.5 text-success" />}
                  <p className="mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    {publishing ? "Publishing to queue" : "Publish complete"}
                  </p>
                </div>
                <p className="mono text-[10px] tabular-nums text-foreground/80">
                  {publishedIds.size} / {MOCK_ASSETS.length}
                </p>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-surface">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-teal to-purple transition-all duration-200"
                  style={{ width: `${publishProgress}%` }}
                />
              </div>
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {MOCK_ASSETS.map((a, i) => (
              <div key={a.id} className="relative">
                <AssetCard asset={a} index={i} onPublish={publishOne} published={publishedIds.has(a.id)} />
                {publishedIds.has(a.id) && (
                  <div className="pointer-events-none absolute right-3 top-3 z-10 inline-flex items-center gap-1 rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-semibold text-success ring-1 ring-success/30 backdrop-blur">
                    <Check className="size-3" /> Published
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
