import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, ArrowRight, Zap, ShieldCheck, BarChart3, Mic2, Upload, Wand2 } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { AssetCard } from "@/components/AssetCard";
import { MOCK_ASSETS } from "@/lib/forge-mock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Forge Content Engine — One upload. Twelve platforms." },
      { name: "description", content: "Premium content engine for serious creators. Upload once, distribute everywhere — with virality scoring, fact-checking, and one-click publishing." },
      { property: "og:title", content: "Forge Content Engine — One upload. Twelve platforms." },
      { property: "og:description", content: "Premium content engine for serious creators." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen">
      <SiteNav />

      {/* Hero */}
      <section className="relative overflow-hidden pt-20 pb-28 md:pt-32 md:pb-40">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--teal)_18%,transparent),transparent_55%),radial-gradient(ellipse_at_bottom_right,color-mix(in_oklab,var(--purple)_15%,transparent),transparent_60%)]" />
        <div className="pointer-events-none absolute inset-0 -z-10 flex items-center justify-center opacity-[0.025]">
          <span className="select-none text-[28vw] font-extrabold uppercase italic tracking-tighter">FORGE</span>
        </div>

        <div className="mx-auto max-w-7xl px-6 text-center" style={{ animation: "var(--animate-reveal)" }}>
          <div className="mono mb-8 inline-flex items-center gap-2 rounded-full border border-teal/20 bg-teal/5 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-teal">
            <span className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-teal" />
            </span>
            Engine v2.4 — Live
          </div>

          <h1 className="text-balance text-5xl font-bold tracking-tighter md:text-7xl lg:text-8xl">
            One upload.<br />
            <span className="text-gradient">Twelve platforms.</span>
          </h1>
          <p className="mx-auto mt-8 max-w-2xl text-pretty text-lg text-muted-foreground">
            The content engine for serious creators. Turn a single video, podcast, or essay into a week's worth of platform-native assets — with virality scoring, fact-checking, and one-click publishing.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              to="/signup"
              className="group inline-flex items-center gap-2 rounded-lg bg-foreground px-6 py-3.5 text-sm font-semibold text-background transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Start free — no card
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
            <Link to="/pricing" className="px-6 py-3.5 text-sm font-medium text-muted-foreground hover:text-foreground">
              See pricing →
            </Link>
          </div>
        </div>

        {/* Dashboard preview */}
        <div className="mx-auto mt-16 max-w-6xl px-6" style={{ animation: "var(--animate-reveal)", animationDelay: "150ms" }}>
          <div className="overflow-hidden rounded-2xl glass-strong ring-1 ring-border">
            <div className="flex items-center justify-between border-b border-border/60 bg-foreground/[0.02] px-5 py-3">
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <span className="size-2.5 rounded-full bg-destructive/30" />
                  <span className="size-2.5 rounded-full bg-warning/30" />
                  <span className="size-2.5 rounded-full bg-success/30" />
                </div>
                <span className="mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  forge / active · brand_voice: petty_richard
                </span>
              </div>
              <span className="mono rounded bg-teal/10 px-2 py-0.5 text-[10px] font-bold text-teal">12 ASSETS READY</span>
            </div>
            <div className="grid gap-4 p-5 md:grid-cols-3">
              {MOCK_ASSETS.slice(0, 3).map((a, i) => (
                <AssetCard key={a.id} asset={a} index={i} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section className="border-y border-border/60 bg-surface/30 py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-16 max-w-2xl">
            <p className="mono mb-3 text-[10px] uppercase tracking-widest text-teal">The workflow</p>
            <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Three steps. Endless distribution.</h2>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {[
              { n: "01", icon: Upload, title: "Ingest", body: "Paste a URL. Drop a video, podcast, PDF, image, or essay. We extract every narrative signal from your source." },
              { n: "02", icon: Mic2, title: "Train your voice", body: "Provide 5–10 samples once. Forge clones your syntax, vocabulary, and rhythm — and remembers it forever." },
              { n: "03", icon: Wand2, title: "Generate assets", body: "One click produces 12+ platform-optimized outputs — each scored, fact-checked, and ready to publish." },
            ].map((s) => (
              <div key={s.n} className="group rounded-2xl glass p-6 transition-all hover:-translate-y-1 hover:ring-glow-purple">
                <div className="mono mb-6 inline-flex size-9 items-center justify-center rounded-lg bg-foreground text-background text-xs font-bold">
                  {s.n}
                </div>
                <s.icon className="mb-3 size-5 text-teal" />
                <h3 className="mb-2 text-lg font-semibold">{s.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-12 flex items-end justify-between">
            <div className="max-w-xl">
              <p className="mono mb-3 text-[10px] uppercase tracking-widest text-teal">12+ platforms</p>
              <h2 className="text-4xl font-bold tracking-tight md:text-5xl">Every channel, native.</h2>
            </div>
            <Link to="/pricing" className="mono hidden text-[11px] uppercase tracking-widest text-muted-foreground hover:text-foreground md:inline">
              See pricing →
            </Link>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {MOCK_ASSETS.slice(0, 6).map((a, i) => (
              <AssetCard key={a.id} asset={a} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Feature row */}
      <section className="border-t border-border/60 bg-surface/30 py-24">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-3">
          {[
            { icon: Zap, title: "Virality scoring", body: "Every hook ranked against real-time trends before you ship it." },
            { icon: ShieldCheck, title: "Fact-checking layer", body: "Inline citations and accuracy verification on every output." },
            { icon: BarChart3, title: "Performance loop", body: "Connect your socials. Forge learns from real engagement, every week." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl glass p-6">
              <f.icon className="mb-4 size-5 text-purple" />
              <h3 className="mb-2 text-lg font-semibold">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-32">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <Sparkles className="mx-auto mb-6 size-6 text-teal" />
          <h2 className="text-balance text-4xl font-bold tracking-tight md:text-6xl">
            Stop posting.<br /><span className="text-gradient">Start distributing.</span>
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-muted-foreground">
            Join creators, founders, and agencies who turned content into a leverage game.
          </p>
          <Link
            to="/signup"
            className="mt-10 inline-flex items-center gap-2 rounded-lg bg-foreground px-6 py-3.5 text-sm font-semibold text-background hover:opacity-90 active:scale-[0.98]"
          >
            Start free <ArrowRight className="size-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
