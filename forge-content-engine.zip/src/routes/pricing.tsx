import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check, Sparkles, ShieldCheck, Lock } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { useStripeCheckout } from "@/hooks/useStripeCheckout";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Forge Content Engine" },
      { name: "description", content: "Simple, premium pricing. Starter $29, Pro $79, Agency $199." },
      { property: "og:title", content: "Pricing — Forge Content Engine" },
      { property: "og:description", content: "Simple, premium pricing." },
    ],
  }),
  component: Pricing,
});

const tiers = [
  {
    name: "Starter",
    priceId: "starter_monthly",
    price: 29,
    blurb: "For creators systemizing their first content engine.",
    features: [
      "10 forge operations / month",
      "1 brand voice profile",
      "All 12+ platforms",
      "Manual export & copy",
      "Fact-checking + trend signals",
    ],
    cta: "Start Starter",
    accent: "teal" as const,
  },
  {
    name: "Pro",
    priceId: "pro_monthly",
    price: 79,
    blurb: "Unlimited generation + analytics for serious operators.",
    features: [
      "Unlimited forge operations",
      "5 brand voice profiles",
      "Virality scoring + trend intel",
      "Direct social scheduling",
      "Performance feedback loop",
    ],
    cta: "Scale to Pro",
    accent: "purple" as const,
    featured: true,
  },
  {
    name: "Agency",
    priceId: "agency_monthly",
    price: 199,
    blurb: "Team seats, white-label, and full API access.",
    features: [
      "Everything in Pro",
      "Unlimited team seats",
      "White-label exports",
      "API access",
      "Priority concierge support",
    ],
    cta: "Deploy Agency",
    accent: "teal" as const,
  },
];

function Pricing() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { openCheckout, closeCheckout, isOpen, checkoutElement } = useStripeCheckout();

  const handleSelect = (priceId: string) => {
    if (loading) return;
    if (!user) {
      navigate({ to: "/signup" });
      return;
    }
    openCheckout({
      priceId,
      customerEmail: user.email ?? undefined,
      userId: user.id,
      returnUrl: `${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
    });
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Ambient background glow */}
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[700px] bg-[radial-gradient(60%_50%_at_50%_0%,color-mix(in_oklab,var(--teal)_8%,transparent),transparent_70%)]" />
      <div className="pointer-events-none absolute -left-40 top-40 -z-10 h-[400px] w-[400px] rounded-full bg-purple/10 blur-[120px]" />
      <div className="pointer-events-none absolute -right-40 top-80 -z-10 h-[400px] w-[400px] rounded-full bg-teal/10 blur-[120px]" />

      <PaymentTestModeBanner />
      <SiteNav />

      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-16 text-center" style={{ animation: "var(--animate-reveal)" }}>
            <div className="mono mb-5 inline-flex items-center gap-2 rounded-full border border-teal/30 bg-teal/5 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-teal">
              <Sparkles className="size-3" /> Pricing
            </div>
            <h1 className="text-balance text-5xl font-bold tracking-tighter md:text-7xl">
              Choose your <span className="text-gradient">power</span>.
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground md:text-lg">
              Scale with your output. Cancel any time. No hidden fees, no overage games.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {tiers.map((t, i) => (
              <div
                key={t.name}
                style={{ animation: `var(--animate-reveal)`, animationDelay: `${i * 80}ms` }}
                className={`group relative flex flex-col rounded-2xl p-8 transition-all duration-300 ${
                  t.featured
                    ? "glass-strong border border-purple/40 ring-glow-purple md:-mt-4 md:mb-4"
                    : "glass hover:border-teal/30 hover:-translate-y-1"
                }`}
              >
                {t.featured && (
                  <div className="mono absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-purple to-teal px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-background shadow-lg">
                    Most refined
                  </div>
                )}

                <div className="mono mb-3 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  {t.name}
                </div>

                <div className="mb-3 flex items-baseline gap-1">
                  <span className="text-6xl font-bold tracking-tighter">${t.price}</span>
                  <span className="text-sm text-muted-foreground">/mo</span>
                </div>

                <p className="mb-7 text-sm leading-relaxed text-muted-foreground">{t.blurb}</p>

                <div className="mb-7 h-px w-full bg-gradient-to-r from-transparent via-border to-transparent" />

                <ul className="mb-8 flex-grow space-y-3.5">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm">
                      <span
                        className={`mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full ${
                          t.accent === "purple" ? "bg-purple/15 text-purple" : "bg-teal/15 text-teal"
                        }`}
                      >
                        <Check className="size-3" strokeWidth={3} />
                      </span>
                      <span className="text-foreground/90">{f}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSelect(t.priceId)}
                  className={`group/btn relative w-full overflow-hidden rounded-xl py-3.5 text-center text-sm font-semibold transition-all duration-300 ${
                    t.featured
                      ? "bg-foreground text-background shadow-[0_8px_30px_-8px_var(--purple)] hover:opacity-95 hover:shadow-[0_12px_40px_-8px_var(--purple)]"
                      : "border border-border bg-background/30 hover:border-teal/40 hover:bg-teal/[0.04] hover:text-teal"
                  }`}
                >
                  <span className="relative z-10">{t.cta}</span>
                </button>
              </div>
            ))}
          </div>

          <div className="mx-auto mt-16 flex max-w-2xl flex-wrap items-center justify-center gap-6 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <ShieldCheck className="size-3.5 text-teal" />
              <span>Stripe-secured</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="size-3.5 text-teal" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="size-3.5 text-teal" />
              <span>14-day money-back</span>
            </div>
          </div>
        </div>
      </section>

      {/* Premium checkout modal */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-background/85 p-4 backdrop-blur-md md:items-center"
          style={{ animation: "var(--animate-fade-in)" }}
          onClick={closeCheckout}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{ animation: "var(--animate-reveal)" }}
            className="relative my-8 w-full max-w-2xl overflow-hidden rounded-3xl glass-strong border border-purple/20 ring-glow-purple"
          >
            <div className="flex items-center justify-between border-b border-border/60 px-6 py-4">
              <div className="flex items-center gap-3">
                <span className="inline-block size-2 rounded-full bg-teal shadow-[0_0_12px_var(--teal)]" />
                <div>
                  <div className="text-sm font-bold tracking-tight">Secure checkout</div>
                  <div className="mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    Stripe · 256-bit TLS
                  </div>
                </div>
              </div>
              <button
                onClick={closeCheckout}
                aria-label="Close checkout"
                className="rounded-full border border-border/60 p-2 text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground"
              >
                <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 6l12 12M18 6l-12 12" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <div className="bg-background/40 p-2 md:p-4">
              {checkoutElement}
            </div>
            <div className="border-t border-border/60 px-6 py-3 text-center">
              <p className="mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Forge Content Engine · by Petty Richard
              </p>
            </div>
          </div>
        </div>
      )}

      <SiteFooter />
    </div>
  );
}
