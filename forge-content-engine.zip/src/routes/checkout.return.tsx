import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/checkout/return")({
  head: () => ({ meta: [{ title: "Payment complete — Forge" }] }),
  validateSearch: (search: Record<string, unknown>): { session_id?: string } => ({
    session_id: typeof search.session_id === "string" ? search.session_id : undefined,
  }),
  component: CheckoutReturn,
});

function CheckoutReturn() {
  const { session_id } = Route.useSearch();
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[600px] bg-[radial-gradient(50%_50%_at_50%_0%,color-mix(in_oklab,var(--teal)_12%,transparent),transparent_70%)]" />
      <SiteNav />
      <section className="flex min-h-[70vh] items-center justify-center px-6 py-24">
        <div
          className="w-full max-w-lg rounded-3xl glass-strong border border-teal/30 p-10 text-center ring-glow-teal"
          style={{ animation: "var(--animate-reveal)" }}
        >
          <div className="mx-auto mb-6 flex size-16 items-center justify-center rounded-full bg-teal/15">
            <CheckCircle2 className="size-9 text-teal" strokeWidth={2} />
          </div>
          <p className="mono mb-3 text-[10px] uppercase tracking-[0.22em] text-teal">Payment confirmed</p>
          <h1 className="text-balance text-4xl font-bold tracking-tighter">
            Welcome to the <span className="text-gradient">Forge</span>.
          </h1>
          <p className="mx-auto mt-4 max-w-sm text-sm text-muted-foreground">
            Your subscription is active. Start forging assets across all 12+ platforms in seconds.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/dashboard"
              className="rounded-xl bg-foreground px-5 py-3 text-sm font-semibold text-background transition-opacity hover:opacity-90"
            >
              Open dashboard
            </Link>
            <Link
              to="/account"
              className="rounded-xl border border-border px-5 py-3 text-sm font-semibold hover:border-teal/40 hover:text-teal"
            >
              Manage billing
            </Link>
          </div>
          {session_id && (
            <p className="mono mt-8 text-[9px] uppercase tracking-[0.22em] text-muted-foreground/70">
              Ref: {session_id.slice(0, 18)}…
            </p>
          )}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
