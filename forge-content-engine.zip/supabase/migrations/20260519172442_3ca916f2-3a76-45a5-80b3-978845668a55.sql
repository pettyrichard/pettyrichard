
-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  subscription_tier text not null default 'free',
  stripe_customer_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "Users view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users insert own profile" on public.profiles for insert with check (auth.uid() = id);

-- Brand voices
create table public.brand_voices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text,
  samples jsonb not null default '[]'::jsonb,
  tone_profile jsonb,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.brand_voices enable row level security;
create policy "Users manage own brand voices" on public.brand_voices for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Content uploads (source pieces)
create table public.content_uploads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  source_type text not null, -- video|audio|blog|pdf|url|podcast|image
  source_url text,
  source_text text,
  file_path text,
  status text not null default 'pending', -- pending|processing|ready|failed
  created_at timestamptz not null default now()
);
alter table public.content_uploads enable row level security;
create policy "Users manage own uploads" on public.content_uploads for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Generated assets
create table public.generated_assets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  upload_id uuid references public.content_uploads(id) on delete cascade,
  brand_voice_id uuid references public.brand_voices(id) on delete set null,
  platform text not null, -- linkedin|x_thread|tiktok|youtube|newsletter|...
  asset_type text not null,
  title text,
  content text not null,
  metadata jsonb,
  virality_score int not null default 0,
  fact_check_status text default 'pending',
  status text not null default 'draft', -- draft|scheduled|published
  scheduled_for timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.generated_assets enable row level security;
create policy "Users manage own assets" on public.generated_assets for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index on public.brand_voices(user_id);
create index on public.content_uploads(user_id);
create index on public.generated_assets(user_id);
create index on public.generated_assets(upload_id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- updated_at trigger
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger brand_voices_touch before update on public.brand_voices for each row execute function public.touch_updated_at();
